            <nav>
                <ul>
                    <li><a href="https://google.com"> Google </a></li>
                    <li><a href="https://yandex.ru"> Yandex </a></li>
                    <li><a href="https://www.myinstants.com/instant/bruh"> BIB </a></li>
                    <li><a href="#cont"> Contacts </a></li>
                </ul>    
            </nav>