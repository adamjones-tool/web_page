

<?php 
 $p = 'Добрый день! это моя первая веб страничка';
?>

<?php 
 $name = 'Юрий';
 $surname = 'Логинов';
 $city = 'Москва';
 $age = 29;
?>


<?php
include 'main.php';
?>

